#version 150

// Дистанция (в блоках) для тумана Blindness / Darkness.
const float DARK_FOG_END = 32.0;

vec4 linear_fog(vec4 inColor, float vertexDistance, float fogStart, float fogEnd, vec4 fogColor) {
    bool isDark = (fogColor.r == 0.0 && fogColor.g == 0.0 && fogColor.b == 0.0);

    float realStart = isDark ? 0.0 : fogStart;
    float realEnd   = isDark ? DARK_FOG_END : fogEnd;

    if (vertexDistance <= realStart) {
        return inColor;
    }

    float fogValue = vertexDistance < realEnd ? smoothstep(realStart, realEnd, vertexDistance) : 1.0;
    return vec4(mix(inColor.rgb, fogColor.rgb, fogValue * fogColor.a), inColor.a);
}

float linear_fog_fade(float vertexDistance, float fogStart, float fogEnd) {
    if (vertexDistance <= fogStart) {
        return 1.0;
    } else if (vertexDistance >= fogEnd) {
        return 0.0;
    }
    return smoothstep(fogEnd, fogStart, vertexDistance);
}

float fog_distance(vec3 pos, int shape) {
    if (shape == 0) {
        return length(pos);
    } else {
        float distXZ = length(pos.xz);
        float distY = abs(pos.y);
        return max(distXZ, distY);
    }
}
